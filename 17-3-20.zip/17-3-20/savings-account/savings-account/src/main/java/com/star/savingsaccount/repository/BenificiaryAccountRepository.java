/**
 * 
 */
package com.star.savingsaccount.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.savingsaccount.entity.BenificiaryAccount;

/**
 * @author User1
 *
 */
public interface BenificiaryAccountRepository extends JpaRepository<BenificiaryAccount, Long> {

}
