/**
 * 
 */
package com.star.savingsaccount.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.savingsaccount.entity.TransactionHistory;

/**
 * @author User1
 *
 */
public interface TransactionHistoryRepository extends JpaRepository<TransactionHistory, Long> {

}
