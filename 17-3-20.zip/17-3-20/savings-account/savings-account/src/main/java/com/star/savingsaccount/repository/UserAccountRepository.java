/**
 * 
 */
package com.star.savingsaccount.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.star.savingsaccount.entity.UserAccount;

/**
 * @author User1
 *
 */
public interface UserAccountRepository extends JpaRepository<UserAccount, Long>{

}
