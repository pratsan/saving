/**
 * 
 */
package com.star.savingsaccount.exception;

/**
 * @author Jyoti
 * @since 
 *
 */
public class FlightExceptions extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8418545146716522194L;

	public FlightExceptions(String message) {
		super(message);
	}
	
	
	

}
