package com.star.savingsaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavingsAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
